# 市場交易量佔比

Market.TQvsVegeQ <- function(df, mkt, vege){
  plot.df <- df %>%
    filter((批發市場 == mkt) & (品項 %in% c(vege,"總蔬菜","總水果"))) %>%
    mutate(
      year = str_extract(Date,"[:digit:]{4}(?=/)") %>% as.numeric
    ) %>%
    group_by(品項, year) %>%
    summarise(
      `總交易量(公噸)` = sum(`交易量(公噸)`, na.rm = T),
      .groups = "drop"
    ) %>%
    spread(., key=品項, value=`總交易量(公噸)`)
  
  total <- df %>% filter(str_detect(品項, "總")) %>% {as.factor(.$品項)} %>% levels
  plot.df$佔比 <- (plot.df[[vege]]/plot.df[[total]])*100
  
  plot.df <- gather(plot.df, key = "品項", value = "總交易量(公噸)", -year)
  
  maxQ <- plot.df %>% filter(品項!="佔比") %>% .$`總交易量(公噸)` %>%
    {max(.,na.rm = T)/(10^floor(log10(max(.,na.rm = T))))} %>%
    {round(.,1)*(10^floor(log10(max(filter(plot.df,品項!="佔比")$`總交易量(公噸)`,na.rm = T))))}
  
  maxPercent <- plot.df %>% filter(品項=="佔比") %>% .$`總交易量(公噸)` %>%
    {max(.,na.rm = T)/(10^floor(log10(max(.,na.rm = T))))} %>%
    {ceiling(.)*(10^floor(log10(max(filter(plot.df,品項=="佔比")$`總交易量(公噸)`,na.rm = T))))}
  
  options(scipen = 200)
  plot <- ggplot(plot.df) +
    theme(plot.caption = element_text(family = "CWTEX-F", hjust = 0),
          plot.title = element_text(face = "bold", family = "CWTEX-BB", size = 16,
                                    hjust = 0.5),
          plot.subtitle = element_text(family = "CWTEX-F", color = "#273746", 
                                       hjust = 0.5),
          axis.text = element_text(family = "Times New Roman"),
          axis.title = element_text(family = "CWTEX-K", size = 13),
          legend.title = element_blank(),
          legend.text = element_text(family = "CWTEX-K"),
          #legend.key.height = unit(0.2,'cm'),
          legend.position = "top") +
    geom_col(aes(x=year,y=`總交易量(公噸)`,fill=品項), position = "dodge",
             data = filter(plot.df,品項!="佔比")) +
    geom_line(aes(x=year,y=`總交易量(公噸)`*(maxQ/maxPercent),color = "佔比"), 
              data = filter(plot.df,品項=="佔比")) +
    geom_point(aes(x=year,y=`總交易量(公噸)`*(maxQ/maxPercent),color = "佔比"), 
               data = filter(plot.df,品項=="佔比")) +
    scale_x_continuous(breaks = unique(plot.df$year)) +
    scale_y_continuous(name = "總交易量（公噸）", 
                       limits = c(0,maxQ+maxQ/10), 
                       sec.axis = sec_axis(~. *(maxPercent/(maxQ)),
                                           name = "佔比（%）")) +
    scale_fill_manual(breaks = c(total,vege),values = c("#FFBC6D","#40414A")) +
    scale_color_manual(values = "black") +
    labs(x = "年",
         title = paste0(mkt,total,"和",vege,"交易量及其佔比"),
         subtitle = paste0("期間：民國",min(unique(plot.df$year))-1911
                           ,"年 ~ 民國",max(unique(plot.df$year))-1911,"年"),
         caption = "資料來源：農產品批發市場交易行情站（2022）。蔬菜產品交易價量走勢圖。")

  return(plot)
}


