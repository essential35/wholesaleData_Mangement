# 年交易量和價格走勢

tradePQ.plot <- function(df, vege){
  # 市場數量
  mkt_n <- as.factor(df$批發市場) %>% levels %>% {length(.)}
  
  plot.df <- df %>%
    mutate(
      year = str_extract(Date,"[:digit:]{4}(?=/)") %>% as.numeric
    ) %>%
    group_by(year) %>%
    summarise(
      `總交易量(公噸)` = sum(`交易量(公噸)`, na.rm = T),
      `平均交易價` = mean(交易價, na.rm = T),
      .groups = "drop"
    )
  
  maxQ <- plot.df$`總交易量(公噸)` %>%
    {max(.,na.rm = T)/(10^floor(log10(max(.,na.rm = T))))} %>%
    {ceiling(.)*(10^floor(log10(max(plot.df$`總交易量(公噸)`,na.rm = T))))}
  
  maxP <- plot.df$`平均交易價` %>%
    {max(.,na.rm = T)/(10^floor(log10(max(.,na.rm = T))))} %>%
    {ceiling(.)*(10^floor(log10(max(plot.df$`平均交易價`,na.rm = T))))}
  
  plot <- ggplot(plot.df) +
    theme(plot.caption = element_text(family = "CWTEX-F"),
          plot.title = element_text(face = "bold", family = "CWTEX-BB", size = 16,
                                    hjust = 0.5),
          plot.subtitle = element_text(family = "CWTEX-F", color = "#273746", 
                                       hjust = 0.5),
          axis.text = element_text(family = "Times New Roman"),
          axis.title = element_text(family = "CWTEX-K", size = 13),
          legend.title = element_blank(),
          legend.text = element_text(family = "CWTEX-K"),
          legend.key.height = unit(0.2,'cm'),
          legend.position = "top") +
    scale_x_continuous(breaks = unique(plot.df$year)) +
    geom_col(aes(x=year,y=`總交易量(公噸)`,fill="交易量"), alpha = 0.7) +
    geom_line(aes(x=year,y=`平均交易價`*(maxQ/maxP), color="交易價")) +
    geom_point(aes(x=year,y=`平均交易價`*(maxQ/maxP), color="交易價")) +
    scale_y_continuous(name = "總交易量（公噸）", 
                       limits = c(0,maxQ), 
                       sec.axis = sec_axis(~. *(maxP/maxQ),
                                           name = "平均交易價（元/公斤）")) +
    scale_fill_manual(values = "#40414A") +
    scale_color_manual(values = "black") +
    labs(x = "年",
         title = paste0(mkt_n,"處批發市場",vege,"年交易量和價格走勢"),
         subtitle = paste0("期間：民國",min(unique(plot.df$year))-1911
                           ,"年 ~ 民國",max(unique(plot.df$year))-1911,"年"),
         caption = "資料來源：農產品批發市場交易行情站，2022。\n 蔬菜產品交易價量走勢圖。")
  
  return(plot)
}
