# 市場交易量之次數分配表

Market.DailyQ.Freq <- function(df, FreqTable, market){
  freqT <- FreqTable %>%
    filter((批發市場 == market) & (變數 == "交易量(公斤)")) %>%  #公噸=公斤/1000
    select(-品項,-變數,-批發市場) %>%
    mutate(groups = rep(1:10, 12)) %>%
    spread(., key = Month, value = 次數) %>%
    .[order(.$groups),] %>%
    select(-groups) %>%
    `colnames<-`(c("交易量(公噸)",str_c(1:12,"月")))
  
  MarketTrade <- df %>%
    filter(批發市場 == market)
  
  freqT <- MarketTrade %>%
    group_by(月份) %>%
    summarise(
      Q1 = quantile(`交易量(公噸)`, na.rm = T)[2],
      Q3 = quantile(`交易量(公噸)`, na.rm = T)[4],
      max = max(`交易量(公噸)`, na.rm = T),
      min = min(`交易量(公噸)`, na.rm = T)
    ) %>%
    mutate(
      dif = Q3-Q1,
      lower = Q1-dif*1.5,
      up = Q3 + 1.5*dif,
      exup = Q3 + 3*dif,
      exlower = Q1-dif*3,
      range = max - min
    ) %>%
    select(月份, lower, up, exup, exlower, range) %>%
    left_join(MarketTrade,., by = "月份") %>%
    mutate(
      outlier = as.numeric((`交易量(公噸)` > up) | (`交易量(公噸)` < lower)),
      extreme = as.numeric((`交易量(公噸)` > exup) | (`交易量(公噸)` < exlower))
    ) %>%
    group_by(月份) %>%
    summarise(
      離群值 = sum(outlier, na.rm = T),
      極端值 = sum(extreme, na.rm = T),
      差距 = mean(range) %>% ifelse(. == -Inf, NA,.)
    ) %>%
    gather(., key = "var", value = "num", - 月份) %>%
    spread(., key = 月份, value = num) %>%
    `colnames<-`(c("交易量(公噸)",str_c(1:12,"月"))) %>%
    rbind(freqT,.) %>%
    mutate(
      合計 = ifelse(`交易量(公噸)` == "差距", 
                     (max(MarketTrade$`交易量(公噸)`, na.rm = T)- min(MarketTrade$`交易量(公噸)`, na.rm = T)),
                     rowSums(.[2:13], na.rm = T))
    ) 
  
  return(freqT)
}