# 價格帶
priceBelt <- function(df, mkt, vege, top_text, bottom_text){
  plot.df <- df %>%
    filter(批發市場 == mkt) %>% 
    {as.data.frame(table(.$`交易量(公噸)`))} %>% 
    .[sort(.$Var1),] %>%
    mutate(
      add = cumsum(Freq),
      percent = (add/sum(Freq))*100,
      interval = cut(percent, breaks = seq(0,100,5)),
      Var1 = as.character(Var1) %>% as.numeric
    ) %>% 
    group_by(interval) %>%
    mutate(
      low = round(min(Var1),1) %>% 
        {ifelse(str_extract(interval,"(?<=\\()[:digit:]") == "0", 0, .)},
      up = round(max(Var1),1),
      `到貨量區間(公噸)` = str_c(low,"-",up) %>% as.factor
    ) %>%
    select(`交易量(公噸)` = Var1, `到貨量區間(公噸)`) %>%
    left_join(filter(df, 批發市場 == mkt),.,by="交易量(公噸)") %>%
    group_by(`到貨量區間(公噸)`) %>%
    summarise(
      top = max(交易價, na.rm = T),
      bottom = min(交易價, na.rm = T),
      .groups = "drop"
    ) %>%
    filter(!is.na(`到貨量區間(公噸)`))
  
  
  priceBelt.Plot <- ggplot(plot.df) +
    theme(plot.caption = element_text(family = "CWTEX-F"),
          plot.title = element_text(face = "bold", family = "CWTEX-BB", size = 16,
                                    hjust = 0.5),
          plot.subtitle = element_text(family = "CWTEX-F", color = "#273746", 
                                       hjust = 0.5),
          axis.text = element_text(family = "Times New Roman"),
          axis.title = element_text(family = "CWTEX-K", size = 13),
          axis.text.x = element_text(angle = 45, vjust = 0.7, hjust = 0.5),
          strip.text = element_text(family = "CWTEX-K", size = 10),
          legend.title = element_text(family = "CWTEX-K"),
          #legend.text = element_text(family = "CWTEX-K"),
          #legend.key.height = unit(0.2,'cm'),
          legend.position = c(0.94, 0.88)) +
    geom_ribbon(aes(x=`到貨量區間(公噸)`,ymax=top, ymin=bottom,group=1), 
                fill = "#00A8FF", alpha=0.3) +
    geom_line(aes(x=`到貨量區間(公噸)`,y=top, group=1, color = "top"),size = 1) +
    geom_line(aes(x=`到貨量區間(公噸)`,y=bottom, group=1, color = "bottom"),size = 1) +
    scale_color_manual(values = c("#FF7020","#53B53F")) +
    geom_point(aes(x=`到貨量區間(公噸)`,y=top, group=1), color = "#53B53F") +
    geom_point(aes(x=`到貨量區間(公噸)`,y=bottom, group=1), color = "#FF7020") +
    geom_text(aes(x=`到貨量區間(公噸)`,y=top+top_text, label = top), 
              check_overlap = TRUE, size = 3.2,
              color = "#547649") +
    geom_text(aes(x=`到貨量區間(公噸)`,y=bottom-bottom_text, label = bottom), 
              check_overlap = TRUE, size = 3.2,
              color = "#D15B20") + 
    scale_y_continuous(breaks = seq(0,max(plot.df$top)+10,10)) +
    labs(
      x = "到貨量區間（公噸）",
      y = "價格（元/公斤）",
      color = "價格屬性",
      title = paste0(mkt,vege,"到貨量對應之價格帶"),
      subtitle = paste0("期間：民國",as.numeric(str_sub(min(df$Date),1,4))-1911,
                        "年 ~ 民國",as.numeric(str_sub(max(df$Date),1,4))-1911,"年"),
      caption = paste0("資料來源：農產品批發市場交易行情站，",str_sub(Sys.Date(),1,4),
                       "。\n 蔬菜產品交易價量走勢圖。")
    )
  
  return(priceBelt.Plot)
}

# 價格帶按季節
priceBelt.season <- function(df, mkt, vege, season, top_text, bottom_text){
  df <- df %>%
    mutate(
      產季 = ifelse(月份 %in% season,"盛產期","非產季")
    )
  
  plot.df <- df %>%
    filter(批發市場 == mkt) %>% 
    {as.data.frame(table(.$`交易量(公噸)`))} %>% 
    .[sort(.$Var1),] %>%
    mutate(
      add = cumsum(Freq),
      percent = (add/sum(Freq))*100,
      interval = cut(percent, breaks = seq(0,100,5)),
      Var1 = as.character(Var1) %>% as.numeric
    ) %>% 
    group_by(interval) %>%
    mutate(
      low = round(min(Var1),1) %>% 
        {ifelse(str_extract(interval,"(?<=\\()[:digit:]") == "0", 0, .)},
      up = round(max(Var1),1),
      `到貨量區間(公噸)` = str_c(low,"-",up) %>% as.factor
    ) %>%
    ungroup %>%
    select(`交易量(公噸)` = Var1, `到貨量區間(公噸)`) %>%
    left_join(filter(df, 批發市場 == mkt),.,by="交易量(公噸)") %>%
    group_by(產季, `到貨量區間(公噸)`) %>%
    summarise(
      top = max(交易價, na.rm = T),
      bottom = min(交易價, na.rm = T),
      .groups = "drop"
    ) %>%
    filter(!is.na(`到貨量區間(公噸)`))
  
  priceBelt.Plot <- ggplot(plot.df) +
    theme(plot.caption = element_text(family = "CWTEX-F"),
          plot.title = element_text(face = "bold", family = "CWTEX-BB", size = 16,
                                    hjust = 0.5),
          plot.subtitle = element_text(family = "CWTEX-F", color = "#273746", 
                                       hjust = 0.5),
          axis.text = element_text(family = "Times New Roman"),
          axis.title = element_text(family = "CWTEX-K", size = 13),
          axis.text.x = element_text(angle = 45, vjust = 0.7, hjust = 0.5),
          strip.text = element_text(family = "CWTEX-K", size = 10),
          legend.title = element_text(family = "CWTEX-K"),
          legend.key.width = unit(0.3,'cm'),
          legend.position = "right") +
    geom_ribbon(aes(x=`到貨量區間(公噸)`,ymax=top, ymin=bottom,group=1), 
                fill = "#00A8FF", alpha=0.3) +
    geom_line(aes(x=`到貨量區間(公噸)`,y=top, group=1, color = "top"),size = 1) +
    geom_line(aes(x=`到貨量區間(公噸)`,y=bottom, group=1, color = "bottom"),size = 1) +
    scale_color_manual(values = c("#FF7020","#53B53F")) +
    geom_point(aes(x=`到貨量區間(公噸)`,y=top, group=1), color = "#53B53F") +
    geom_point(aes(x=`到貨量區間(公噸)`,y=bottom, group=1), color = "#FF7020") +
    geom_text(aes(x=`到貨量區間(公噸)`,y=top+top_text, label = top), 
              check_overlap = TRUE, size = 3.2,
              color = "#547649") +
    geom_text(aes(x=`到貨量區間(公噸)`,y=bottom-bottom_text, label = bottom), 
              check_overlap = TRUE, size = 3.2,
              color = "#D15B20") + 
    scale_y_continuous(breaks = seq(0,max(plot.df$top)+10,10)) +
    facet_grid(產季~.) +
    labs(
      x = "到貨量區間（公噸）",
      y = "價格（元/公斤）",
      color = "價格屬性",
      title = paste0(mkt,vege,"到貨量對應之價格帶——按產季分"),
      subtitle = paste0("期間：民國",as.numeric(str_sub(min(df$Date),1,4))-1911,
                        "年 ~ 民國",as.numeric(str_sub(max(df$Date),1,4))-1911,"年"),
      caption = paste0("資料來源：農產品批發市場交易行情站，",str_sub(Sys.Date(),1,4),
                       "。\n 蔬菜產品交易價量走勢圖。")
    )
  
  return(priceBelt.Plot)
}

