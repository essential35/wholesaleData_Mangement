# 製作 上下限 & 間距

group_inter <- function(DF){
  DF %>%
    group_by(批發市場, 品項) %>%
    summarise(
      minQ = min(`交易量(公斤)`, na.rm = T),
      maxQ = max(`交易量(公斤)`, na.rm = T),
      interQ = (maxQ - minQ)/10,
      
      minP = min(`交易價`, na.rm = T),
      maxP = max(`交易價`, na.rm = T),
      interP = (maxP - minP)/10,
      
      .groups = "drop"
    ) %>%
    mutate(
      位數 = log10(interQ) %>% floor(.),
      interQ2 = ifelse(maxQ >= minQ+9*round(interQ/10^(位數))*10^(位數),
                       round(interQ/10^(位數),0)*10^(位數),
                       round(interQ/10^(位數-1),0)*10^(位數-1)),
      upQ = round((minQ+9*interQ2)/10^(位數),0)*10^(位數),
      lowQ = upQ-interQ2*8,
      
      interP2 = round(interP,0),
      lowP = round(minP+interP2,0),
      upP = round(lowP+interP2*8,0)
    ) %>%
    select(批發市場, 品項,
               minQ, maxQ, interQ, interQ2, upQ, lowQ,
               minP, maxP, interP, interP2, upP, lowP) %>%
    tidyr::gather(., key = "variable", value = "num",  -批發市場,-品項) %>%
    mutate(
      group = ifelse(str_detect(variable, "(Q$|Q2$)"),1, NA) %>%
        ifelse(str_detect(variable, "(P$|P2$)"),2, .)
    ) %>%
    return()
}

