# 市場交易量價盒鬚圖

Market.Daily.BoxPlot <- function(df, market, vege, PorQ){
  market.df <- df %>%
    filter(批發市場 == market) %>%
    mutate(
      year = str_extract(Date,"[:digit:]{4}(?=/)") %>% as.numeric
    )
  
  if (str_detect(PorQ, "交易量")){
    maxQ <- market.df$`交易量(公噸)` %>%
      {max(., na.rm = T)/(10^floor(log10(max(., na.rm = T))))} %>%
      {ceiling(.)*(10^floor(log10(max(market.df$`交易量(公噸)`,na.rm = T))))}
    
    plot <- ggplot(market.df, aes(x=as.factor(月份),y=`交易量(公噸)`)) +
      theme(plot.caption = element_text(family = "CWTEX-F"),
            plot.title = element_text(face = "bold", family = "CWTEX-BB", size = 16,
                                      hjust = 0.5),
            plot.subtitle = element_text(family = "CWTEX-F", color = "#273746", 
                                         hjust = 0.5),
            axis.text = element_text(family = "Times New Roman"),
            axis.title = element_text(family = "CWTEX-K", size = 13),
            legend.title = element_blank(),
            legend.text = element_text(family = "CWTEX-K"),
            #legend.key.height = unit(0.2,'cm'),
            legend.position = "top") +
      geom_boxplot(outlier.alpha = 0.5) +
      scale_y_continuous(limits = c(0,maxQ)) +
      labs(x = "月",
           title = paste0(market,vege,"交易量盒鬚圖"),
           subtitle = paste0("期間：民國",min(unique(market.df$year))-1911
                             ,"年 ~ 民國",max(unique(market.df$year))-1911,"年"),
           caption = "資料來源：農產品批發市場交易行情站，2022。\n 蔬菜產品交易價量走勢圖。")
    
  } else if (str_detect(PorQ, "交易價")){
    maxP <- market.df$`平均交易價` %>%
      {max(.,na.rm = T)/(10^floor(log10(max(.,na.rm = T))))} %>%
      {ceiling(.)*(10^floor(log10(max(plot.df$`平均交易價`,na.rm = T))))}
    
    plot <- ggplot(market.df, aes(x=as.factor(月份),y=`交易價`)) +
      theme(plot.caption = element_text(family = "CWTEX-F"),
            plot.title = element_text(face = "bold", family = "CWTEX-BB", size = 16,
                                      hjust = 0.5),
            plot.subtitle = element_text(family = "CWTEX-F", color = "#273746", 
                                         hjust = 0.5),
            axis.text = element_text(family = "Times New Roman"),
            axis.title = element_text(family = "CWTEX-K", size = 13),
            legend.title = element_blank(),
            legend.text = element_text(family = "CWTEX-K"),
            #legend.key.height = unit(0.2,'cm'),
            legend.position = "top") +
      geom_boxplot(outlier.alpha = 0.5) +
      scale_y_continuous(limits = c(0,maxP)) +
      labs(x = "月",
           y = "交易價（元/公斤）",
           title = paste0(market,vege,"交易價盒鬚圖"),
           subtitle = paste0("期間：民國",min(unique(market.df$year))-1911
                             ,"年 ~ 民國",max(unique(market.df$year))-1911,"年"),
           caption = "資料來源：農產品批發市場交易行情站，2022。\n 蔬菜產品交易價量走勢圖。")
  }
  
  return(plot)
}