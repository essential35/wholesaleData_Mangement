# 市場交易量之敘述統計

Basic.Daily <- function(df, market, PorQ){
  PorQ <- ifelse(str_detect(PorQ, "交易量"), "交易量(公噸)", "交易價")
  df.Basic <- df %>%
    filter(批發市場 == market)
  
  BasicStat <- df.Basic %>%
    group_by(月份) %>%
    summarise(
      平均數 = across(PorQ, mean, na.rm = T)[[1]] %>% round(.,2),
      標準差 = across(PorQ, sd, na.rm = T)[[1]] %>% round(.,2),
      .groups = "drop"
    ) %>%
    rbind(.,
          data.frame(月份 = "合計",
                       平均數 = mean(df.Basic[[PorQ]], na.rm = T) %>% round(.,2),
                       標準差 = sd(df.Basic[[PorQ]], na.rm = T) %>% round(.,2))
    ) %>%
    mutate(
      月份 = as.numeric(月份),
      變異係數 = (標準差/平均數) %>% {round(.,2)}
    ) %>%
    gather(., key = "var", value = "num", -月份) %>%
    spread(., key = 月份, value = num) %>%
    `colnames<-`(c(PorQ,str_c(1:12,"月"),"合計"))
  
  return(BasicStat)
}

