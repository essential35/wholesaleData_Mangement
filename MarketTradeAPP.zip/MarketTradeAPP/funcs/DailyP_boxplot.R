# 日交易價盒鬚圖

DailyP.boxplot <- function(df,vege){
  # 市場數量
  mkt_n <- as.factor(df$批發市場) %>% levels %>% {length(.)}
  
  plot.df <- df %>%
    group_by(Date, 月份) %>%
    summarise(
      `日交易價` = mean(`交易價`, na.rm = T),
      .groups = "drop"
    ) %>%
    mutate(
      year = str_extract(Date,"[:digit:]{4}(?=/)") %>% as.numeric
    )
  
  maxP <- plot.df$`日交易價` %>%
    {max(.,na.rm = T)/(10^floor(log10(max(.,na.rm = T))))} %>%
    {round(.,1)*(10^floor(log10(max(plot.df$`日交易價`,na.rm = T))))}
  
  plot <- ggplot(plot.df, aes(x=as.factor(月份),y=`日交易價`)) +
    theme(plot.caption = element_text(family = "CWTEX-F"),
          plot.title = element_text(face = "bold", family = "CWTEX-BB", size = 16,
                                    hjust = 0.5),
          plot.subtitle = element_text(family = "CWTEX-F", color = "#273746", 
                                       hjust = 0.5),
          axis.text = element_text(family = "Times New Roman"),
          axis.title = element_text(family = "CWTEX-K", size = 13),
          legend.title = element_blank(),
          legend.text = element_text(family = "CWTEX-K"),
          #legend.key.height = unit(0.2,'cm'),
          legend.position = "top") +
    geom_boxplot(outlier.alpha = 0.5) +
    scale_y_continuous(limits = c(0,maxP)) +
    labs(x = "月",
         y = "交易價（元/公斤）",
         title = paste0(mkt_n,"處批發市場",vege,"日交易價盒鬚圖"),
         subtitle = paste0("期間：民國",min(unique(plot.df$year))-1911
                           ,"年 ~ 民國",max(unique(plot.df$year))-1911,"年"),
         caption = "資料來源：農產品批發市場交易行情站，2022。\n 蔬菜產品交易價量走勢圖。")
  
  return(plot)  
}

