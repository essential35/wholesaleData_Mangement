# 市場蔬菜交易價格列聯表
Market.P.CongenTable <- function(df, mkt, vege, situation = 1, lowP.bonder = NA){ 
  # situation=1,2,3,4; lowP.bonder = 第一二生產成本、監控成本
  
  up <- df %>% filter(批發市場 == mkt) %>% 
    {as.data.frame(table(.$交易價))} %>% 
    .[sort(.$Var1,decreasing = T),] %>%
    mutate(add = cumsum(Freq)) %>% 
    filter(add <= (sum(Freq)*0.05)) %>% {as.character(.$Var1[NROW(.)])} %>% as.numeric
  
  if (situation == 1){
    low <- df %>% filter(批發市場 == mkt) %>% 
      {as.data.frame(table(.$交易價))} %>% 
      mutate(add = cumsum(Freq)) %>% 
      filter(add <= (sum(Freq)*0.05)) %>% {as.character(.$Var1[NROW(.)])} %>% as.numeric
    
    varlow <- "低於最低5%價格門檻"
    
  }else if (situation == 2){
    low <- lowP.bonder
    varlow <- "低於近3年第一種生產成本門檻"
  }else if (situation == 3){
    low <- lowP.bonder
    varlow <- "低於近3年第二種生產成本門檻"
  }else if (situation == 4){
    low <- lowP.bonder
    varlow <- "低於蔬菜監控價格門檻"
  }
  
  # 列聯表
  CongenTable <- matrix(ncol = 7) %>% as.data.frame() %>%
    `colnames<-`(c("interval", "Freq", "type", "佔比", "批發市場", "品項", "月份"))
  
  for (mon in c(1:12)) {
    CongenTable <- df %>%
      filter((批發市場 == mkt)) %>%
      filter(月份 == mon) %>%
      {cut(.$交易價, breaks = c(-Inf, low, up, Inf))} %>%
      {table(., dnn = list("interval"))} %>%
      {as.data.frame(.)} %>%
      mutate(
        type = ifelse(str_detect(interval, "(?<=\\()(-Inf)"), 
                      paste0(varlow, "（",
                             str_extract(interval,"[[:digit:].]+"),"元/公斤）"),
                      NA) %>%
          ifelse(str_detect(interval, "Inf(?=\\])"), 
                 paste0("高於最高5%價格門檻（",
                        str_extract(interval,"[[:digit:].]+"),"元/公斤）"),
                 .) %>%
          ifelse(is.na(.), "價格介於中間90%",.),
        批發市場 = mkt,
        品項 = vege,
        月份 = mon
      ) %>%
      group_by(月份) %>%
      mutate(
        佔比 = round((Freq/sum(Freq))*100, 2)
      ) %>%
      rbind(CongenTable,.)
  }
  
  CT.output <- CongenTable[-1,] %>%  
    select(Freq, type, 月份, 佔比) %>%
    gather(., key = freq_percent, value = num, c(Freq,佔比)) %>%
    mutate(type = ifelse(freq_percent == "Freq", "次數", "佔比") %>% str_c(type, "_", .)) %>%
    select(-freq_percent) %>%
    spread(., key = type, value = num) %>%
    mutate(
      月份 = str_c(月份,"月"),
      列小計_次數 = rowSums(.[,c(3,5,7)])
    ) %>%  
    rbind(.,
          c("欄小計", round((sum(.[,3])/sum(.[,8]))*100, 2), sum(.[,3]), 
            round((sum(.[,5])/sum(.[,8]))*100,2), sum(.[,5]),
            round((sum(.[,7])/sum(.[,8]))*100, 2), sum(.[,7]),
            sum(.[,8]))) %>%
    mutate_at(2:NCOL(.), as.numeric)
  
  return(CT.output)
}

# 市場蔬菜交易價格次數分配圖
Market.CT.plot <- function(CT, vege, mkt, yr1=100, yr2=110, situation = 1){
  CT %>%
    select(月份, contains("次數")) %>%
    select(-contains("列小計")) %>%
    filter(月份 != "欄小計") %>%
    pivot_longer(cols = colnames(.)[2:4], 
                 names_to = "index",
                 values_to = "次數") %>%
    mutate(
      月份 = str_remove(月份,"月") %>% as.numeric,
      index = str_remove_all(index, "_次數") %>% 
        {str_c(str_sub(.,1,6),"\n",str_sub(.,7,str_locate(.,"（")[1]-1),"\n",str_sub(.,str_locate(.,"（")[1]))},
      index = factor(index, levels = unique(index))
    ) %>% 
    ggplot(., aes(x=月份,y=次數, color=index)) +
    theme(plot.caption = element_text(family = "CWTEX-F"),
          plot.title = element_text(face = "bold", family = "CWTEX-BB", size = 16,
                                    hjust = 0.5),
          plot.subtitle = element_text(family = "CWTEX-F", color = "#273746", 
                                       hjust = 0.5),
          axis.text = element_text(family = "Times New Roman"),
          axis.title = element_text(family = "CWTEX-K", size = 13),
          strip.text = element_text(family = "CWTEX-K", size = 10),
          #legend.title = element_blank(),
          #legend.text = element_text(family = "CWTEX-K"),
          #legend.key.height = unit(0.2,'cm'),
          legend.position = "none") +
    geom_line() +
    geom_point() +
    facet_grid(index~., scales = "free_y") +
    scale_x_continuous(breaks = c(1:12)) +
    labs(
      title = paste0(mkt,vege,"交易價格次數分配圖","——情境",situation),
      subtitle = paste0("期間：民國",yr1
                        ,"年 ~ 民國",yr2,"年"),
      caption = "資料來源：農產品批發市場交易行情站，2022。\n 蔬菜產品交易價量走勢圖。"
    ) %>%
    return()
}

