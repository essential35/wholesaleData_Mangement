# 大宗蔬菜交易情況ui

# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(shinythemes)
library(dplyr)
library(stringr)
library(openxlsx)
library(periscope)
library(ggplot2)
library(tidyr)

# Define UI for application that draws a histogram
ui <- shinyUI(fluidPage(
    theme = shinytheme("cosmo"),
    
    # Application title
    navbarPage(
        title = "蔬果批發市場交易情況",
        
        # 資料合併
        tabPanel("資料集合併",
            sidebarLayout(
                sidebarPanel(
                    numericInput("startyr", "資料起始年", 1996, min=1996, max=Inf),
                    numericInput("endyr","資料結束年",1996, min=1996, max=Inf),
                    fileInput("files", "上傳批發市場資料", multiple = T,
                              accept = c("xls/xlsx", ".xlsx", ".xls")),
                    
                    div(
                        h4("檔案上傳限制："),
                        p("1. 檔案需為「.xls」或「.xlsx」檔。"),
                        p("2. 檔案名稱格式為「(蔬菜名字)_(市場簡稱).xls」，例如「小白菜_台中市.xlsx」。")
                    ),
                    
                    tags$hr(),
                    
                    h3("Download"),
                    # 下載合併資料
                    h5("- 合併資料下載："),
                    # download data button
                    downloadButton("dl", "Combine Data")
                ),
                mainPanel(
                    tabsetPanel(
                        tabPanel("原始資料", 
                                 DT::dataTableOutput(outputId = "originData")),
                        tabPanel("所有日資料",
                                 DT::dataTableOutput(outputId = "allDayData"))
                    )
                )
            )
        ),
        
        # 所有批發市場資料呈現
        tabPanel("所有批發市場",
            sidebarLayout(
                sidebarPanel(
                    # file
                    fileInput("combine_file", "1. 上傳批發市場整體資料", multiple = T,
                              accept = c("xls/xlsx", ".xlsx", ".xls")),
                    
                    helpText(
                        h4("檔案上傳限制："),
                        p("1. 檔案需為「.xls」或「.xlsx」檔。")
                    ),
                    
                    # choose vegetable
                    selectInput("vege", label = "2. 請選擇蔬果",
                                choices = list("--請選擇--", "總蔬菜", 
                                               "甘藍","包心白","青花苔",
                                               "白花椰","紅蘿蔔","青江菜",
                                               "小白菜", "空心菜","粉蔥","日蔥",
                                               "北蔥","絲瓜","花胡瓜","蘿蔔",
                                               "大蒜","洋蔥",
                                               "金鑽鳳梨","愛文芒果","網室木瓜",
                                               "檸檬","香蕉","紅龍果紅肉","紅龍果白肉",
                                               "番石榴","鳳梨釋迦","釋迦","金柑","文旦",
                                               "蓮霧","大西瓜","梨"),
                                selected = "--請選擇--"),
                    # choose year
                    sliderInput("yrRange", 
                                label = "3. 年份選擇：",
                                min = 1996, max = (lubridate::year(Sys.Date())-1), 
                                value = c(1996, lubridate::year(Sys.Date())-1),
                                sep = "", width = "100%"),
                ),
                mainPanel(
                    h4("年交易量和價格走勢"),
                    plotOutput("vegePQ_plot"),
                    downloadButton("dl_vegePQplot"),
                    h4("盒鬚圖"),
                    fluidRow(
                        splitLayout(cellWidths = c("50%", "50%"), 
                                    plotOutput("Box_17DayQ"), plotOutput("Box_17DayP")),
                        splitLayout(downloadButton("dl_Box_17DayQ"), 
                                    downloadButton("dl_Box_17DayP"))
                    )
                )
            )
        ),
        
        # 個別批發市場資料呈現
        tabPanel("個別市場",
             sidebarLayout(
                 sidebarPanel(
                     helpText("使用資料與所有批發市場同。"),
                     # choose market
                     selectInput("market", label = "1. 請選擇批發市場",
                                 choices = list("--請選擇--", "台北一", 
                                                "台北二","板橋區","三重區",
                                                "宜蘭市","桃農","台中市",
                                                "豐原區", "永靖鄉","溪湖鎮",
                                                "南投市","西螺鎮","高雄市",
                                                "鳳山區","屏東市","台東市","花蓮市",
                                                "嘉義市","東勢區"),
                                 selected = "--請選擇--"),
                     
                     # choose vegetable
                     selectInput("vege2", label = "2. 請選擇蔬果",
                                 choices = list("--請選擇--", "總蔬菜", 
                                                "甘藍","包心白","青花苔",
                                                "白花椰","紅蘿蔔","青江菜",
                                                "小白菜", "空心菜","粉蔥","日蔥",
                                                "北蔥","絲瓜","花胡瓜","蘿蔔",
                                                "大蒜","洋蔥",
                                                "金鑽鳳梨","愛文芒果","網室木瓜",
                                                "檸檬","香蕉","紅龍果紅肉","紅龍果白肉",
                                                "番石榴","鳳梨釋迦","釋迦","金柑","文旦",
                                                "蓮霧","大西瓜","梨"),
                                 selected = "--請選擇--"),
                     # choose year
                     sliderInput("yrRange2", 
                                 label = "3. 年份選擇：",
                                 min = 1996, max = (lubridate::year(Sys.Date())-1), 
                                 value = c(1996, lubridate::year(Sys.Date())-1),
                                 sep = "", width = "100%"),
                     # input cost
                     p(strong("4. 輸入生產成本及蔬菜監控成本：")),
                     numericInput("cost1", "第一種生產成本", value = 0),
                     helpText("p.s. 近3年該蔬果第一種生產成本的平均值。"),
                     numericInput("cost2", "第二種生產成本", value = 0),
                     helpText("p.s. 近3年該蔬果第二種生產成本的平均值。"),
                     numericInput("cost_gov", "蔬菜監控成本", value = 0)
                 ),
                 mainPanel(
                     tabsetPanel(
                         tabPanel("交易量Tables",
                                  h4("交易量次數分配表"),
                                  DT::dataTableOutput("mkt_QFreq"),
                                  downloadButton("dl_mkt_QFreq"),
                                  h4("交易量敘述統計"),
                                  DT::dataTableOutput("mkt_QBasic"),
                                  downloadButton("dl_mkt_QBasic")),
                         tabPanel("交易量Plots",
                             fluidRow(
                                 splitLayout(h4("市場交易量盒鬚圖"), 
                                             h4("市場總蔬菜及單一蔬菜交易量及其佔比")),
                                 splitLayout(cellWidths = c("50%", "50%"), 
                                             plotOutput("mkt_vegeBoxPlot"), 
                                             plotOutput("mkt_vegeVsPlot")),
                                 splitLayout(downloadButton("dl_mkt_vegeBoxPlot"), 
                                             downloadButton("dl_mkt_vegeVsPlot"))
                             )
                         ),
                         tabPanel("市場交易價情形",
                                  h4("交易價敘述統計"),
                                  DT::dataTableOutput("mkt_PFreq"),
                                  downloadButton("dl_mkt_PFreq"),
                                  
                                  h4("市場交易價盒鬚圖"),
                                  plotOutput("mkt_vegePboxplot"),
                                  downloadButton("dl_mkt_vegePboxplot")
                          ),
                         tabPanel("市場高低價",
                                  htmlOutput("mkt_Pbonder1"),
                                  htmlOutput("mkt_PminMax"),
                                  
                                  h3("市場高低價列聯表"),
                                  tabsetPanel(
                                      tabPanel("情境一",
                                               DT::dataTableOutput("mkt_vegeCT1")
                                      ),
                                      tabPanel("情境二、三、四",
                                               DT::dataTableOutput("mkt_vegeCT2")
                                      )
                                  ),
                                  downloadButton("dl_mkt_vegeCTs", label = "所有列聯表"),
                                  
                                  h3("市場高低價次數分配圖"),
                                  tabsetPanel(
                                      tabPanel("情境一",
                                               plotOutput("mkt_vegeCTplot1"),
                                               downloadButton("dl_mkt_vegeCTplot1", "情境一")
                                      ),
                                      tabPanel("情境二、三、四",
                                               plotOutput("mkt_vegeCTplot2"),
                                               downloadButton("dl_mkt_vegeCTplot2", "情境二、三、四")
                                      )
                                  )
                         ),
                         tabPanel("價格帶",
                                  splitLayout(numericInput("top_text", "與top line距離", value = 5),
                                              numericInput("bottom_text", "與bottom line距離", value = 5)),
                                  
                                  h3("市場價格帶"),
                                  plotOutput("mkt_priceBelt"),
                                  downloadButton("dl_mkt_priceBelt")

                         )
                     )
                 )
             )
        ),
        
        # design of navbar
        tags$style(HTML(".navbar-header { width:30%; text-align: center}
                   .navbar-brand { width: 100%; text-align: center }"))
    )
))
