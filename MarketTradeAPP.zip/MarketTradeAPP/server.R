# 大宗蔬菜交易情況server

# This is the server logic of a Shiny web application. You can run the
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(shinythemes)
library(dplyr)
library(stringr)
library(openxlsx)
library(periscope)
library(ggplot2)
library(tidyr)

options(shiny.maxRequestSize=1000*1024^2)

# Define server logic required to draw a histogram
server <- shinyServer(function(input, output) {
    
    # 資料合併
    everyday <- reactive({
        # create a dataframe include all dates 
        DayTrade <- data.frame(
            day = rep(1:31, times = length(c(input$startyr:input$endyr))*12),
            month = rep(1:12, each = 31),
            year = rep(c(input$startyr:input$endyr), each = 31*12)
        ) %>%
            .[-c(which(.$month %in% c(4,6,9,11) & (.$day > 30)),
                 which((.$month == 2) & (.$year %% 4 == 0) & (.$day > 29)),
                 which((.$month == 2) & (.$year %% 4 != 0) & (.$day > 28))),] %>%
            mutate(Date = str_c(year, "/", month, "/", day) %>% as.Date(.)) %>%
            .[order(.$Date),] %>%
            select(Date, month) %>%
            rename(., 月份 = month) %>%
            mutate(Date = as.character(Date) %>% str_replace_all(., "-","/"),
                   月份 = str_extract(Date,"(?<=/)[:digit:]+(?=/)"))
        
        DayTrade
    })
    
    # data combine
    combine_df <- reactive({
        req(input$files)
        
        # input all data
        all_pq <- matrix(ncol = 8) %>% as.data.frame() %>%
            `colnames<-`(c("Date","Day","月份","交易量(公斤)","交易量(公噸)",
                           "交易價","批發市場","品項"))
        
        for(i in 1:length(input$files[,1])){
            all_pq <- readxl::read_excel(input$files[[i, 'datapath']],
                                         col_names = c("交易日期","平均價",
                                                       "交易量(公斤)")) %>%
                .[-c(1:3),] %>%
                mutate(
                    平均價 = as.numeric(平均價),
                    `交易量(公斤)` = as.numeric(`交易量(公斤)`),
                    `交易量(公噸)` = `交易量(公斤)`/1000
                ) %>%
                tibble::add_column(
                    年 = str_extract(.$交易日期,"^[:digit:]+(?=/)") %>% 
                        as.numeric %>% {.+1911},
                    月份 = str_extract(.$交易日期,"(?<=/)[:digit:]+(?=/)"),
                    日 = str_extract(.$交易日期,"(?<=/)[:digit:]+$"),
                    .before = 2
                ) %>%
                tibble::add_column(
                    Date = str_c(.$年,"/",.$月份,"/",.$日)
                ) %>%
                select(Date, 月份, `交易量(公斤)`, `交易量(公噸)`, 交易價 = 平均價) %>%
                left_join(everyday(),., by=c("Date","月份")) %>%
                mutate(
                    批發市場 = str_extract(input$files[[i, "name"]],
                                       "(?<=_)[\u4E00-\u9FFF]+(?=.xls)"),
                    品項 = str_extract(input$files[[i, "name"]],
                                     "^[\u4E00-\u9FFF]+(?=_)"),
                    DayLabel = as.Date(Date) %>% lubridate::wday(., label=TRUE)
                ) %>%
                left_join(., 
                          data.frame(DayLabel = c("Sun","Mon","Tue","Wed","Thu","Fri","Sat"),
                                     Day = c("週日","週一","週二","週三","週四","週五","週六")),
                          by="DayLabel") %>%
                select(Date, Day, 月份, `交易量(公斤)`, `交易量(公噸)`, 交易價, 批發市場, 品項) %>%
                rbind(all_pq, .)
        }
        
        all_pq <- all_pq %>%
            group_by(批發市場, 品項) %>%
            mutate(
                `前一天交易量(公斤)` = lag(`交易量(公斤)`),
                `前一天交易價` = lag(`交易價`),
                `交易量差(公斤)` = `交易量(公斤)` - `前一天交易量(公斤)`,
                `交易價差` = `交易價` - `前一天交易價`,
                `交易量漲跌` = `交易量差(公斤)`/`前一天交易量(公斤)`,
                `交易價漲跌` = `交易價差`/`前一天交易價`,
                月份 = as.numeric(月份),
                `有無原始資料` = ifelse(is.na(`交易量(公斤)`),FALSE,TRUE)
            ) 
        
        all_pq
    })
    
    # final all date data
    finalAllDayTrade <- reactive({
        combine_df() %>% .[order(.$批發市場),]
    })
    
    # 原始資料
    output$originData <- DT::renderDataTable({
        finalAllDayTrade() %>% .[which(!is.na(.$`交易量(公斤)`)),]
    })
    
    # 所有日資料
    output$allDayData <- DT::renderDataTable({
        finalAllDayTrade()
    })
    
    # download data
    output$dl <- downloadHandler(
        filename = function() {
            "Combine_Data.xlsx"
        },
        content = function(file) {
            all_pq2 <- list(
                `原始檔_台北一～西螺鎮` = finalAllDayTrade() %>% 
                    .[which(!is.na(.$`交易量(公斤)`)),] %>% .[order(.$批發市場),] %>%
                    filter(批發市場 %in% c("台北一","台北二","板橋區","三重區","宜蘭市",
                                       "桃農","台中市","豐原區","永靖鄉","溪湖鎮","南投市",
                                       "西螺鎮")),
                `原始檔_高雄市～花蓮市` = finalAllDayTrade() %>%
                    .[which(!is.na(.$`交易量(公斤)`)),] %>% .[order(.$批發市場),] %>%
                    filter(!(批發市場 %in% c("台北一","台北二","板橋區","三重區","宜蘭市",
                                         "桃農","台中市","豐原區","永靖鄉","溪湖鎮","南投市",
                                         "西螺鎮"))),
                `日交易_含漲跌幅_台北一～西螺鎮` = finalAllDayTrade() %>%
                    filter(批發市場 %in% c("台北一","台北二","板橋區","三重區","宜蘭市",
                                       "桃農","台中市","豐原區","永靖鄉","溪湖鎮","南投市",
                                       "西螺鎮")),
                `日交易_含漲跌幅_高雄市～花蓮市` = finalAllDayTrade() %>%
                    filter(!(批發市場 %in% c("台北一","台北二","板橋區","三重區","宜蘭市",
                                         "桃農","台中市","豐原區","永靖鄉","溪湖鎮","南投市",
                                         "西螺鎮")))
            )
            
            createStyle(textDecoration = "BOLD", border = "bottom", fontName = "BaiKuai") %>%
                write.xlsx(x=all_pq2, file = file,headerStyle = .)
        }
    )
    
    
    # 年交易量和價格走勢
    source("./funcs/TradePQ_plot.R")
    # 日交易量盒鬚圖
    source("./funcs/DailyTrade_boxplot.R")
    # 日交易價盒鬚圖
    source("./funcs/DailyP_boxplot.R")
    # 市場交易量之次數分配表
    source("./funcs/Mkt_DailyTrade_FreqTable.R")
    # 市場交易量之敘述統計
    source("./funcs/Market_DailyTrade_BasicStat.R")
    # 市場交易量盒鬚圖
    source("./funcs/Market_DailyTrade_boxplot.R")
    # 市場交易量佔比
    source("./funcs/Market_TotalQ_vegeQ.R")
    # 市場價格列聯表&次數分配圖
    source("./funcs/Market_P_CongenTable.R")
    # 市場價格帶
    source("./funcs/priceBelt.R")
    
    df <- reactive({
        inputdf <- input$combine_file
        
        df1 <- readxl::read_excel(inputdf$datapath, sheet = 3,
                           col_types = c("text","text",
                                         "numeric","numeric","numeric","numeric",
                                         "text","text",
                                         "numeric","numeric","numeric","numeric",
                                         "numeric","numeric","logical"))
        df2 <- readxl::read_excel(inputdf$datapath, sheet = 4,
                                  col_types = c("text","text",
                                                "numeric","numeric","numeric","numeric",
                                                "text","text",
                                                "numeric","numeric","numeric","numeric",
                                                "numeric","numeric","logical"))
        df <- rbind(df1, df2) %>%
            select(Date, Day, 月份, `交易量(公斤)`, `交易量(公噸)`, 交易價, 批發市場, 品項)
        
        df
    })
    # 年交易量和價格走勢
    PQ_plot <- reactive({
        PQ_plot <- df() %>% 
            filter((品項 == input$vege) & 
                       (as.numeric(str_extract(Date,"[:digit:]{4}(?=/)")) >= input$yrRange[1])) %>%
            tradePQ.plot(., input$vege)
        
        PQ_plot
    })
    
    output$vegePQ_plot <- renderPlot({
        PQ_plot()
    })
    
    output$dl_vegePQplot <- downloadHandler(
        filename = function() {
            paste0("17處批發市場",input$vege,"年交易量和價格走勢（",input$yrRange[1],
                   "-",input$yrRange[2],"）.png")
        },
        content = function(file) {
            ggsave(file, plot = PQ_plot(), units="in", width=8, height=5,
                   device="png")
        }
    )
    
    # 日交易量盒鬚圖
    box_17Q <- reactive({
        Q_boxplot <- df() %>% 
            filter((品項 == input$vege) & 
                       (as.numeric(str_extract(Date,"[:digit:]{4}(?=/)")) >= input$yrRange[1])) %>%
            DailyTrade.boxplot(., input$vege)
        
        Q_boxplot
    })
    
    output$Box_17DayQ <- renderPlot({
        box_17Q()
    })
    
    output$dl_Box_17DayQ <- downloadHandler(
        filename = function() {
            paste0("17處批發市場",input$vege,"日交易量盒鬚圖（",input$yrRange[1],
                   "-",input$yrRange[2],"）.png")
        },
        content = function(file) {
            ggsave(file, plot = box_17Q(), units="in", width=8, height=5,
                   device="png")
        }
    )
    
    # 日交易價盒鬚圖
    box_17P <- reactive({
        P_boxplot <- df() %>% 
            filter((品項 == input$vege) & 
                       (as.numeric(str_extract(Date,"[:digit:]{4}(?=/)")) >= input$yrRange[1])) %>%
            DailyP.boxplot(., input$vege)
        
        P_boxplot
    })
    
    output$Box_17DayP <- renderPlot({
        box_17P()
    })
    
    output$dl_Box_17DayP <- downloadHandler(
        filename = function() {
            paste0("17處批發市場",input$vege,"日交易價盒鬚圖（",input$yrRange[1],
                   "-",input$yrRange[2],"）.png")
        },
        content = function(file) {
            ggsave(file, plot = box_17P(), units="in", width=8, height=5,
                   device="png")
        }
    )
    
    # 個別市場
    ## 市場交易量次數分配表
    mkt.QFreq <- reactive({
        freqT <- df() %>% 
            filter((as.numeric(str_extract(Date,"[:digit:]{4}(?=/)")) >= input$yrRange2[1])) %>%
            Market.DailyQ.Freq(., input$market, input$vege2)
        
        freqT
    })
    
    output$mkt_QFreq <- DT::renderDataTable({
        DT::datatable(mkt.QFreq(), options = list(pageLength = 15))
    })
    
    output$dl_mkt_QFreq <- downloadHandler(
        filename = function() {
            paste0(input$market,input$vege2,"交易量次數分配表（",input$yrRange2[1],
                   "-",input$yrRange2[2],"）.xlsx")
        },
        content = function(file) {
           createStyle(textDecoration = "BOLD", border = "bottom", fontName = "BaiKuai") %>%
                write.xlsx(mkt.QFreq(), file = file, headerStyle = .)
        }
    )
    
    ## 市場敘述統計
    mkt.QBasic <- reactive({
        basic <- df() %>% 
            filter((品項 == input$vege2) & 
                       (as.numeric(str_extract(Date,"[:digit:]{4}(?=/)")) >= input$yrRange2[1])) %>%
            Basic.Daily(., input$market, "交易量(公噸)")
        
        basic
    })
    
    output$mkt_QBasic <- DT::renderDataTable({
        mkt.QBasic()
    })
    
    output$dl_mkt_QBasic <- downloadHandler(
        filename = function() {
            paste0(input$market,input$vege2,"交易量敘述統計（",input$yrRange2[1],
                   "-",input$yrRange2[2],"）.xlsx")
        },
        content = function(file) {
            createStyle(textDecoration = "BOLD", border = "bottom", fontName = "BaiKuai") %>%
                write.xlsx(mkt.QBasic(), file = file, headerStyle = .)
        }
    )
    
    
    ## 市場交易量盒鬚圖
    mkt.vegeboxplot <- reactive({
        mkt.boxplot <- df() %>% 
            filter((品項 == input$vege2) & 
                       (as.numeric(str_extract(Date,"[:digit:]{4}(?=/)")) >= input$yrRange2[1])) %>%
            Market.Daily.BoxPlot(., input$market, input$vege2, "交易量")
        
        mkt.boxplot
    })
    
    output$mkt_vegeBoxPlot <- renderPlot({
        mkt.vegeboxplot()
    })
    
    output$dl_mkt_vegeBoxPlot <- downloadHandler(
        filename = function() {
            paste0(input$market,input$vege2,"交易量盒鬚圖（",input$yrRange2[1],
                   "-",input$yrRange2[2],"）.png")
        },
        content = function(file) {
            ggsave(file, plot = mkt.vegeboxplot(), units="in", width=8, height=5,
                   device="png")
        }
    )
    
    ## 市場總蔬菜及單一蔬菜交易量及其佔比
    mkt.vegeVSplot <- reactive({
        VSplot <- df() %>%  
            mutate(
                year = str_extract(Date,"[:digit:]{4}(?=/)") %>% as.numeric
            ) %>%
            filter(year >= input$yrRange2[1]) %>%
            Market.TQvsVegeQ(., input$market, input$vege2)
        
        VSplot
    })
    
    output$mkt_vegeVsPlot <- renderPlot({
        mkt.vegeVSplot()
    })
    
    output$dl_mkt_vegeVsPlot <- downloadHandler(
        filename = function() {
            paste0(input$market,"總蔬菜和",input$vege2,"交易量及其佔比（",
                   input$yrRange2[1],"-",input$yrRange2[2],"）.png")
        },
        content = function(file) {
            ggsave(file, plot = mkt.vegeVSplot(), units="in", width=8, height=5,
                   device="png")
        }
    )
    
    ## 市場交易價之敘述統計
    FreqPvege <- reactive({
        vege <- df() %>% 
            filter((品項 == input$vege2) & 
                       (as.numeric(str_extract(Date,"[:digit:]{4}(?=/)")) >= input$yrRange2[1]))
        
        
        basic <- rbind(Market.DailyP.Freq(vege, input$market, input$vege2),
                       Basic.Daily(vege, input$market, "交易價"))
        basic
    })
    
    output$mkt_PFreq <- DT::renderDataTable({
        DT::datatable(FreqPvege(), options = list(pageLength = 20))
    })
    
    output$dl_mkt_PFreq <- downloadHandler(
        filename = function() {
            paste0(input$market,input$vege2,"交易價敘述統計（",input$yrRange2[1],
                   "-",input$yrRange2[2],"）.xlsx")
        },
        content = function(file) {
            createStyle(textDecoration = "BOLD", border = "bottom", fontName = "BaiKuai") %>%
                write.xlsx(FreqPvege(), file = file, headerStyle = .)
        }
    )
    
    ## 市場交易價盒鬚圖
    mkt.PBoxPlot <- reactive({
        PBoxPlot <- df() %>% 
            filter((品項 == input$vege2) & 
                   (as.numeric(str_extract(Date,"[:digit:]{4}(?=/)")) >= input$yrRange2[1])) %>%
        Market.Daily.BoxPlot(., input$market, input$vege2,"交易價")
        
        PBoxPlot
    })
    
    output$mkt_vegePboxplot <- renderPlot({
        mkt.PBoxPlot()
    })
    
    output$dl_mkt_vegePboxplot <- downloadHandler(
        filename = function() {
            paste0(input$market, input$vege2,"交易價盒鬚圖（",
                   input$yrRange2[1],"-",input$yrRange2[2],"）.png")
        },
        content = function(file) {
            ggsave(file, plot = mkt.PBoxPlot(), units="in", width=8, height=5,
                   device="png")
        }
    )
    
    ## 高低價
    ### 情境一
    vegeCT1 <- reactive({
        CT1 <- df() %>% 
            filter((品項 == input$vege2) & 
                       (as.numeric(str_extract(Date,"[:digit:]{4}(?=/)")) >= input$yrRange2[1])) %>%
            Market.P.CongenTable(., input$market, input$vege2, situation = 1)
        
        CT1
    })
    
    output$mkt_vegeCT1 <- DT::renderDataTable({
        DT::datatable(vegeCT1(), options = list(pageLength = 20))
    })
    
    ### 情境二
    vegeCT2 <- reactive({
        CT2 <- data.frame(月份 = c(str_c(c(1:12),"月"),"欄小計"))
        
        vege <- df() %>% 
            filter((品項 == input$vege2) & 
                       (as.numeric(str_extract(Date,"[:digit:]{4}(?=/)")) >= input$yrRange2[1]))
        
        for (p in c(input$cost1, input$cost2, input$cost_gov)){
            CT2 <- select(Market.P.CongenTable(vege, input$market, input$vege2, 
                                               situation = which(c(input$cost1, input$cost2, input$cost_gov) == p)+1, 
                                               lowP.bonder = p), 月份, contains("低於")) %>%
                left_join(CT2, ., by = "月份")
        }
        
        CT2
        
    })
    
    output$mkt_vegeCT2 <- DT::renderDataTable({
        DT::datatable(vegeCT2(), options = list(pageLength = 20))
    })
    
    
    output$dl_mkt_vegeCTs <- downloadHandler(  # CT1, CT2 download
        filename = function() {
            paste0(input$market,input$vege2,"交易價格之列聯表——情境一（",input$yrRange2[1],
                   "-",input$yrRange2[2],"）.xlsx")
        },
        content = function(file) {
            CTs <- list(
                `情境一` = vegeCT1(),
                `情境二、三、四` = vegeCT2()
            )
            
            createStyle(textDecoration = "BOLD", border = "bottom", fontName = "BaiKuai") %>%
                write.xlsx(CTs, file = file,headerStyle = .)
        }
    )
    
    
    # plots
    output$mkt_Pbonder1 <- renderUI({
        low <- colnames(vegeCT1()) %>% .[grepl("低於",.)] %>% 
            {str_extract(.[1],"(?<=（).+(?=）)")}
        
        up <- colnames(vegeCT1()) %>% .[grepl("高於",.)] %>% 
            {str_extract(.[1],"(?<=（).+(?=）)")}
        
        HTML(paste(paste0("- 最低5%價格：", low), paste0("- 最高5%價格：", up), sep = '<br/>'))
    })
    
    output$mkt_PminMax <- renderUI({
        minP <- df() %>% 
            filter((品項 == input$vege2) & 
                       (as.numeric(str_extract(Date,"[:digit:]{4}(?=/)")) >= input$yrRange2[1])) %>%
            filter(批發市場 == input$market) %>% 
            {min(.$交易價, na.rm = T)}
        
        maxP <- df() %>% 
            filter((品項 == input$vege2) & 
                       (as.numeric(str_extract(Date,"[:digit:]{4}(?=/)")) >= input$yrRange2[1])) %>%
            filter(批發市場 == input$market) %>% 
            {max(.$交易價, na.rm = T)}
        
        HTML(paste(paste0("- 最低價：", minP, "元/公斤"), 
                   paste0("- 最高價：", maxP, "元/公斤"), sep = '<br/>'))
    })
    
    
    ctplot1 <- reactive({
        Market.CT.plot(vegeCT1(), input$vege2, input$market, situation = 1)
    })
    output$mkt_vegeCTplot1 <- renderPlot({
        ctplot1()
    })
    
    ctplot2 <- reactive({
        Market.CT.plot(vegeCT2(), input$vege2, input$market, situation = "2、3、4")
    })
    output$mkt_vegeCTplot2 <- renderPlot({
        ctplot2()
    })
    
    output$dl_mkt_vegeCTplot1 <- downloadHandler(
        filename = function() {
            paste0(input$market, input$vege2,"交易價格次數分配圖情境1（",
                   input$yrRange2[1],"-",input$yrRange2[2],"）.png")
        },
        content = function(file) {
            ggsave(file, plot = ctplot1(), units="in", width=8, height=5,
                   device="png")
        }
    )
    
    output$dl_mkt_vegeCTplot2 <- downloadHandler(
        filename = function() {
            paste0(input$market, input$vege2,"交易價格次數分配圖情境2、3、4（",
                   input$yrRange2[1],"-",input$yrRange2[2],"）.png")
        },
        content = function(file) {
            ggsave(file, plot = ctplot2(), units="in", width=8, height=5,
                   device="png")
        }
    )
    
    # 市場價格帶
    plot.priceBelt <- reactive({
        priceBeltPlot <- df() %>% 
            filter((品項 == input$vege2) & 
                   (as.numeric(str_extract(Date,"[:digit:]{4}(?=/)")) >= input$yrRange2[1])) %>%
            priceBelt(.,input$market, input$vege2,
                      top_text = input$top_text, bottom_text = input$bottom_text)
        
        priceBeltPlot
    })
    
    output$mkt_priceBelt <- renderPlot({
        plot.priceBelt()
    })
    
    output$dl_mkt_priceBelt <- downloadHandler(
        filename = function() {
            paste0(input$market, input$vege2,"到貨量對應之價格帶（",
                   input$yrRange2[1],"-",input$yrRange2[2],"）.png")
        },
        content = function(file) {
            ggsave(file, plot = plot.priceBelt(), units="in", width=8, height=5,
                   device="png")
        }
    )
    
    ## 市場價格帶——產季
    plot.priceBelt.season <- reactive({
        month <- as.numeric(input$produce_month)
        
        priceBeltPlot <- df() %>% 
            filter((品項 == input$vege2) & 
                       (as.numeric(str_extract(Date,"[:digit:]{4}(?=/)")) >= input$yrRange2[1])) %>%
            priceBelt.season(.,input$market, input$vege2, month,
                      top_text = input$top_text, bottom_text = input$bottom_text)
        
        priceBeltPlot
    })
    
    output$mkt_priceBelt_season <- renderPlot({
        plot.priceBelt.season()
    })
    
    output$dl_mkt_priceBelt_season <- downloadHandler(
        filename = function() {
            paste0(input$market, input$vege2,"到貨量對應之價格帶_產季（",
                   input$yrRange2[1],"-",input$yrRange2[2],"）.png")
        },
        content = function(file) {
            ggsave(file, plot = plot.priceBelt.season(), units="in", width=8, height=5,
                   device="png")
        }
    )
})
